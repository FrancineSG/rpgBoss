package rpgboss.model.event

case class EventError(message: String)